<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

  <title></title>
     <link  rel="stylesheet" href="css/bootstrap.css">
     <link rel="stylesheet" type="text/css" href="css/mystyle.css">
     <style type="text/css">
       .save_button {
    min-width: 100px;
    max-width: 100px;
}
     </style>
</head>

<body> 
  <div class="container-fluid ">
    <div class="container">
      <div class="row">
       <div class="col-sm-3">

          <div>
            <p>Login User Info: </p>
            <p>fname Date: 2074/11/06 </p>
            <p>Time: 12:00</p> 
            <p>Type: admin</p>
          </div>

         </br>
         <table class="button" width="40%">
          <button type="button" class="save_button">Home</button></br>
          <button type="button" class="save_button">Username</button></br>
          <button type="button" class="save_button">password</button></br>
          <button type="button" class="save_button">Policy Define</button></br></br><p>----------------------------</p></br>
          <button type="button" class="save_button">Admission Form</button></br>
          <button type="button" class="save_button">Entrance Form</button></br>
          <button type="button" class="save_button">Student Record</button></br>
          <button type="button" class="save_button">Staff Info</button></br>
          <button type="button" class="save_button">Department</button></br>
          <button type="button" class="save_button">syllabus</button></br>
          <button type="button" class="save_button">Attendance</button></br>
          <button type="button" class="save_button">Notice</button></br>
          <button type="button" class="save_button">Program Events</button></br>
          <button type="button" class="save_button">Account</button></br>
          <button type="button" class="save_button">Library Info</button></br>
          <button type="button" class="save_button">Student Id Card</button></br>
          <button type="button" class="save_button">Video Upload</button></br>
          <button type="button" class="save_button">Audio Upload</button></br>
          <button type="button" class="save_button">Gallery</button></br>
          <button type="button" class="save_button">User manage</button></br>
          <button type="button" class="save_button">Subject Manage</button></br>
          <button type="button" class="save_button">Department Manage</button></br>
          <button type="button" class="save_button">Student Blog</button></br>
          <button type="button" class="save_button">Approve Info</button></br>
          <button type="button" class="save_button"> Bulk Email</button></br>
         </table>
       </div><!-- end of col-sm-4 -->


       <div class="col-sm-9" style="border: 4px solid grey;border-radius: 11px;">
        <div class="container">
          <div class="row">
           <div class="col-sm-7">

            <center>
         <h2 style="border: 2px inset;background-color: #f1f1f1;border-radius: 5px; padding: 10px;">The international Association of Lions club 32532 Nepal</h2>
         <hr>
            </center>
           </div><!-- end of col-sm-2 -->

              <div class="col-sm-2">

            <center>
          <img align="right" src="images.png" style=" margin: 16px 34px 0 0;
    border: 3px inset;
    border-radius: 7px;
    height: 104px;
    width: 114px;">
            </center>
           </div><!-- end of col-sm-2 -->
            </div>
           </div>
         
          </br>
          </br>
          </br>
          </br>
         <div class="container">
          <div class="row">
            <center>
           <div class="col-sm-2">
             <button type="button">Logo</button></br></br>
           </div><!-- end of col-sm-2 -->

            <div class="col-sm-2">
             <button type="button">Logo</button></br></br>
           </div><!-- end of col-sm-2 -->

            <div class="col-sm-2">
             <button type="button">Logo</button></br></br>
           </div><!-- end of col-sm-2 -->
           </center>
             </div><!-- end of row -->
         </div><!-- end of container -->
        

        <div class="container">
          <div class="row">
            <div class="col-sm-9" style="margin: 0 0 0 -19px;">
              <h2><center style="border: 2px inset;background-color: #f1f1f1;border-radius: 5px;">Member Info</center></h2>
              <hr>
           </div> 
       </div>
         </div>
       </br>

        <form class="form-horizontal">
          <div class="form-group">
              <div class="col-md-2"> <label>Occupation: </label></div>
              <div class="col-md-4">
              <input type="text" class="form-control" name="" placeholder="Occupation">
            </div>
            <div class="col-md-2"><label> Office name :  </label></div>
            <div class="col-md-4"><input type="text" class="form-control" name="" placeholder="office"></div>
            </div>
            <div class="form-group">
              <div class="col-md-2"><label>Business : </label></div>
              <div class="col-md-10"><input class="form-control" type="text" name="" placeholder="buisness"></div>
            </div>
            <div class="form-group">
              <div class="col-md-2"><label> Education: </label></div>
              <div class="col-md-10">
              <select class="form-control" name="">
              <option value="0"> Education 1</option>
              <option value="1"> Education 2</option>
              <option value="2"> Education 3</option>
              <option value="3"> Education 4</option>
              <option value="4"> Education 5</option>
              <option value="5"> Education 6</option>
              <option value="6"> Education 7</option>
             </select>
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-2"><label>CV : </label></div>
              <div class="col-md-10"><input class="form-control" type="file" name="" placeholder=""></div>
            </div>
        </form>

         

        <!-- <form>
           
            <span>Occupation: </span><input type="text" name="" placeholder=""> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  

           <span>Office name :  </span><input type="text" name="" placeholder="">
           </br></br></br>

             <span>Business :  </span><input type="text" name="" placeholder="">
           </br></br></br>

             
             <span> Education: </span>
             <select name="">
              <option value="0"> Education 1</option>
              <option value="1"> Education 2</option>
              <option value="2"> Education 3</option>
              <option value="3"> Education 4</option>
              <option value="4"> Education 5</option>
              <option value="5"> Education 6</option>
              <option value="6"> Education 7</option>
             </select>

           </br></br></br>
            
           
            <div class="form-inline">
            <span> CV : </span><input class="form-control" type="file" name="" placeholder="">
            </div>
           </br></br></br>-->

            

           
            

       </div><!-- end of col-sm-9 -->
     </div><!--end of row -->
   </div><!-- end of container-->
 </div> <!-- end of container-fluid-->
</body>
</html>

 