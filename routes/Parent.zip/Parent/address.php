
<?php 
Route::get('address', function() {
    return 'address';
})->name('address');
