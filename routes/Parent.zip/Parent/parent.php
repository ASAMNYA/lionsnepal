
<?php 
Route::get('parent', function() {
    return 'parent';
})->name('parent');
